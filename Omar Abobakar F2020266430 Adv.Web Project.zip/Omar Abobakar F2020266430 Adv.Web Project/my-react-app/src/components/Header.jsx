import React from 'react'

export const Header = () => {
    return (
        <h2>
            Personal Account Manager
        </h2>
    )
}

